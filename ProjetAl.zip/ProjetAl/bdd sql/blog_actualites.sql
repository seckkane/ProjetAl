-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost
-- Généré le : jeu. 25 fév. 2021 à 09:38
-- Version du serveur :  10.4.14-MariaDB
-- Version de PHP : 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `blog_actualites`
--

-- --------------------------------------------------------

--
-- Structure de la table `article`
--

CREATE TABLE `article` (
  `numero_article` int(11) NOT NULL,
  `path_image` varchar(100) NOT NULL,
  `title_article` varchar(150) NOT NULL,
  `descrip_article` text NOT NULL,
  `code_categorie` varchar(10) NOT NULL,
  `username` varchar(20) NOT NULL,
  `pub_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `article`
--

INSERT INTO `article` (`numero_article`, `path_image`, `title_article`, `descrip_article`, `code_categorie`, `username`, `pub_date`) VALUES
(1, '../images/fd.jpg', 'Kédougou : Ce que l’on sait sur les deux adolescents morts noyés dans le fleuve Gambie', 'A en croire toujours  ces familles, c’est de là que ces deux enfants se seraient rendus directement au fleuve pour une partie de  baignade. Alertés par les cris au secours des enfants, les riverains se sont rendus sur les lieux et ont fait  appel aux sapeurs-pompiers. Après d’intenses recherches, les éléments de la 62ème compagnie d’incendie et de secours n’ont pu retrouver aucun corps. Et aux environs de 22 heures, avec les conditions d’éclairage qui faisaient défaut, ils étaient obligés de  suspendre les recherches. C’est ce matin à 07 h 40 mn qu’ils ont repêché le premier corps sans vie d’A.D âgé de 12 ans. Et le deuxième corps, celui de M.T.T âgé de 06 ans a été sorti de l’eau ce matin vers 11 heures.\r\n\r\nLes deux corps ont été acheminés à la morgue du centre de santé de Kédougou pour les besoins d’une autopsie, nous renseigne un proche.\r\n\r\nIl faut cependant rappeler que ces cas de noyades sont devenus récurrents dans ce fleuve Gambie surtout au niveau de Wassa et de Nétékhoto  qui sont fréquentés régulièrement par des enfants pour des sorties et des promenades amicales  sans gilets de sauvetage.', 'fd', 'issounet', '2021-02-25'),
(2, '../images/fd.jpg', 'Le tailleur découvre l\'infidélité de l\'épouse de son père et la fait chanter pour coucher avec elle', 'Une histoire d\'adultère éclabousse le Quartier Keur Niang de Touba. M. T. N., un tailleur âgé de 21 ans, a découvert la relation adultérine de K. D., l\'épouse de  son père, qu entretenait une relation extraconjugale avec un chauffeur.\r\n\r\nLa mariée infidèle envoyait ses photos et  vidéos nues, via WhatsApp, à son amant. Le tailleur a volé les images obscènes de sa tante, deuxième épouse de son père, qu\'il faisait chanter.\r\n\r\nSelon le quotidien Source A qui vend la mèche dans sa parution de ce jeudi, le jeune tailleur menaçait sa tante de diffuser les images et vidéos compromettantes si elle refusait de coucher avec lui.\r\n\r\nDevant les enquêteurs, la tante infidèle a reconnu les faits, mais soutient qu\'elle n\'a jamais rendu visite à son amant. Le tailleur et sa grande soeur ont été ainsi déférés, hier mercredi, au parquet.\r\n\r\nIls sont poursuivis pour accès et maintien frauduleux sur un outil informatique, collecte déloyale et diffusion de données à caractère personnel, atteinte à l\'intimité de la vie privée d\'autrui et harcèlement sexuel. ', 'fd', 'issounet', '2021-02-25'),
(3, '../images/sp.jpg', 'Classement KPMG : Sadio Mane, 10e joueur le plus cher au monde', '1. Kylian Mbappé (PSG) : 185 millions d\'euros\r\n\r\n 2. Harry Kane (Tottenham) : 125 millions d\'euros\r\n\r\n3. Raheem Sterling (Man City) : 125 millions d\'euros\r\n\r\n 4. Jadon Sancho (Dortmund) : 118 millions d\'euros\r\n\r\n5. Marcus Rashford (Man Utd) : 115 millions d\'euros\r\n\r\n 6. Neymar (PSG) : 115 millions d\'euros\r\n\r\n7. Mohamed Salah (Liverpool) : 115 millions d\'euros\r\n\r\n 8. Kevin De Bruyne (Man City) : 114 millions d\'euros\r\n\r\n9. Trent Alexander-Arnold (Liverpool) : 111 millions d\'euros\r\n\r\n10. Sadio Mané (Liverpool) : 110 millions d\'euros', 'sp', 'issounet', '2021-02-25'),
(4, '../images/sp.jpg', 'Ligue africaine des champions : Le Tfc contraint au nul par le Zamalek', 'Le Teungueth Fc a été tenu en échec (0-0), ce soir, au stade Lat Dior de Thiès, par le Zamalek du Caire (Egypte) en Ligue africaine des champions. Un match qui comptait pour la 2e journée de la poule D.\r\n\r\nLes hommes de Youssouf Dabo, qui avaient perdu leur première sortie contre l’Espérance de Tunis par 2-1, espéraient signer leur première victoire dans cette compétition. Malgré de nombreuses occasions, les Rufisquois n’ont pas pu marquer le but victorieux.\r\n\r\nIls décrochent tout de même leur premier point dans ce groupe et iront à la recherche de leur premier succès, lors de la 3e journée, face au Mouloudia club d’Alger.   ', 'sp', 'mrdiop', '2021-02-25'),
(5, '../images/pol.jpg', 'Précision de Malick Gakou : \"Je ne suis pas l\'artisan des retrouvailles entre Macky Sall et Idy\"', 'Malick Gakou botte en touche et dément avoir joué un quelconque rôle dans les retrouvailles entre Idrissa Seck et le président Macky Sall.\r\n\r\nDans un entretien au quotidien L\'observateur, il apporte des précisions à ce sujet. \"Je ne suis pas l\'artisan des retrouvailles entre le président de la république Macky Sall et Idrissa Seck, président du Conseil économique social et environnemental\", éclaire-t-il d\'emblée, dans les colonnes du journal.\r\n\r\n\" Je n\'ai joué aucun rôle ni direct ni indirect \" renchérit le leader du Grand parti, avant d\'ajouter : \"Sur les plus de 16 millions de Sénégalais, je n\'ai jamais amené un seul chez le président Macky Sall, encore moins un quelconque opposant. C\'est une affirmation mensongère, grotesque et sans fondement\". ', 'pol', 'mrdiop', '2021-02-25'),
(6, '../images/pol.jpg', 'Levée de l\'immunité parlementaire d\'Ousmane Sonko : On connaît la date de la plénière !', 'L\'Assemblée nationale va acter la levée de l\'immunité parlementaire du député Ousmane Sonko, lors d\'une plénière prévue vendredi prochain à 11 h. C\'est ce qui ressort de la réunion tenue ce matin par la conférence des présidents de l\'Assemblée. \r\nNous y reviendrons.', 'pol', 'mrdiop', '2021-02-25'),
(7, '../images/rel.png', 'Le Khalife de Médina Baye face à la presse, ce vendredi', 'Le Khalife de Médina Baye, Cheikh Mahy Niass fera face à la presse, ce vendredi. Ce sera après la prière, dans la mosquée de la cité religieuse. \r\nLe numéro un de la Fayda va s\'exprimer sur l\'actualité, d\'après une note de sa cellule de communication.', 'rel', 'mrdiop', '2021-02-25'),
(8, '../images/rel.png', '\"Blasphème de l\'Islam\" : Un Mauritanien arrêté aux Maristes risque 2 ans de prison', 'M. V. M., ressortissant mauritanien reconverti chrétien, a été arrêté pour \"blasphème de l’islam et injures au prophète Mahomet\".\r\n\r\nJugé hier, devant le tribunal des flagrants délits de Dakar, le parquet a requis contre lui 2 ans de prison ferme, informe Le Soleil.\r\n\r\nDans une vidéo postée sur Facebook, le Mauritanien, entré clandestinement au Sénégal, menaçait même de brûler le Saint-Coran.\r\n\r\nFace aux enquêteurs, il confie avoir été obligé. Sous la contrainte d’amis tunisiens, rapporte, pour sa part, le quotidien L’Observateur.\r\n\r\nLe Mauritanien est issue d’une famille musulmane très pieuse. Après sa reconversion, il s’est réfugié en Tunisie avant d’être rapatrié dans son pays. Il sera fixé sur son sort le 16 novembre prochain. ', 'rel', 'mrdiop', '2021-02-25'),
(9, '../images/rel.png', 'El Hadji Moustapha Guèye : \"Achoura, ce n\'est pas une fête, mais une tragédie avec l\'extermination de la famille du Prophète\"', '\r\nLe prêcheur El Hadji Moustapha Guèye a asséné ses vérités aux personnes qui célèbrent Achoura (Tamkharite) comme une fête. \"Ce n\'est pas une fête, mais une tragédie qui consacre l\'extermination de la famille du prophète de l\'islam\", tient-il à rappeler. \"Ousseynou, dit-il, a été décapité et sa tête transportée à Sham où elle sera enterrée. Il s\'en est suivi une fête grandiose pour se réjouir de l\'extermination sur terre des membres de la famille du prophète\".  \r\n\"La seule recommandation faite pour ce jour, est de jeûner\", conclut Moustapha Guèye. ', 'rel', 'mrdiop', '2021-02-25'),
(10, '../images/rel.png', 'Istanbul: vers une réouverture de Sainte-Sophie au culte musulman?', '\r\nCe jeudi est une journée décisive pour l’un des édifices les plus connus au monde : le statut de Sainte-Sophie d’Istanbul, en Turquie, doit être débattu au Conseil d’État. Sa décision pourrait permettre la réouverture de Sainte-Sophie  – qui fut d’abord église byzantine pendant neuf siècles, puis mosquée ottomane, puis musée sous la République – au culte musulman, comme le souhaite le président Erdogan.\r\n\r\nDe notre correspondante à Istanbul, \r\n\r\nLe Conseil d’État se réunit ce jeudi pour examiner la plainte d’une association musulmane. Celle-ci soutient que le décret de 1934 qui a permis de transformer Sainte-Sophie – qui était alors une mosquée – en musée est un faux. Que Mustafa Kemal Atatürk, le fondateur de la République qui a pourtant signé ce décret et visité le musée dès son ouverture en février 1935, n’a en réalité jamais pris une telle décision.\r\n\r\nD’un point de vue légal, jusqu’à récemment, cette plainte n’avait quasiment aucune chance d’aboutir, car la même chambre du Conseil d’État a débouté la même association pour la même requête plusieurs fois ces 15 dernières années... Mais il y a deux éléments nouveaux qui font penser qu’aujourd’hui la plus haute juridiction administrative pourrait changer d’avis.\r\n\r\nErdogan veut reconquérir Sainte-Sophie\r\n\r\nPremièrement, elle a révoqué l’an dernier le statut de musée accordé en 1945 à Saint-Sauveur-in-Chora, une ancienne église byzantine de premier plan convertie en mosquée après la conquête ottomane en 1453 – exactement comme Sainte-Sophie. Ensuite, et surtout, le président Erdogan a lui-même promis de rouvrir la « mosquée Sainte-Sophie », et sa mainmise sur l’appareil judiciaire ne fait guère de doute.\r\n\r\nMais Recep Tayyip Erdogan est au pouvoir depuis 18 ans. Pourquoi agir si tard ? Dans la famille politique du président, rendre à l’islam la coupole de Sainte-Sophie est un rêve aussi vieux que sa transformation en musée. Mais à partir du moment où il a accédé au pouvoir, par pragmatisme Tayyip Erdogan n’a cessé de repousser les appels à reconvertir Sainte-Sophie en mosquée. Il avait l’habitude de répondre que les fidèles devaient d’abord remplir la grande mosquée de Sultanahmet, située juste en face.\r\n\r\nC’est seulement l’an dernier, à la veille d’élections locales où son parti a essuyé de très lourdes défaites – en perdant notamment la mairie d’Istanbul – que le chef de l’État a commencé à réclamer sa reconversion en mosquée. Dans les coulisses du pouvoir, il se dit que le président souhaiterait y organiser une grande prière collective le 15 juillet, le jour des commémorations du coup d’État manqué de l’été 2016.\r\n\r\nSainte-Sophie, une question de principe\r\n\r\nSur la scène intérieure, Erdogan n\'a pas grand-chose à gagner à ce changement de statut de Sainte-Sophie. À l’exception des musulmans les plus conservateurs et des minorités chrétiennes, les Turcs sont globalement indifférents au sort de Sainte-Sophie, même s’ils ne s’opposent pas, bien sûr, à ce qu’elle redevienne mosquée. Mais c’est loin d’être une demande pressante de la majorité des Turcs – électeurs du président compris – qui se préoccupent surtout de leur situation économique. Un geste aussi symbolique que la réislamisation de Sainte-Sophie serait certes un moyen de faire diversion, mais ses effets n’auraient qu’un temps.\r\n\r\nIl faut peut-être chercher les motivations du président turc dans ses relations de plus en plus compliquées avec l’Europe, et l’Occident en général. À l’époque où la candidature de la Turquie à l’Union européenne avait encore un sens – ou du moins, un avenir –, jamais Recep Tayyip Erdogan ne se serait risqué à toucher au statut de Sainte-Sophie. Mais à l’heure où ses actions en Syrie, en Libye et en Méditerranée orientale ne cessent de susciter les critiques des Occidentaux, le président turc fait désormais de Sainte-Sophie une question de souveraineté nationale.', 'rel', 'mrdiop', '2021-02-25'),
(11, '../images/pol.jpg', 'Affaire Sonko, Watergate? : « La simple mention de BBY suffit au classement de ce dossier et au déclenchement d’une procédure de destitution »', 'Le président de Pastef-Les-Patriotes Ousmane Sonko ne rate pas sa cible. Dans un post publié sur facebook, il charge et tire sur le chef de l’Etat qu’il accuse ouvertement d’être l’instigateur du « complot » qui le vise dans l’affaire de viol présumé sur une masseuse. Une sortie en réaction à l’entretien que Macky Sall a accordé à Rfi et au cours de laquelle il botte en touche toute idée de complot.\r\n\r\n«Que peut-il dire lorsque, dans un procès-verbal d’enquête de la gendarmerie portant sur une affaire fomentée contre son ennemi (pardon \"adversaire\"), il est clairement mentionné l’implication d’un responsable de sa coalition BBY ? La simple mention de l’acronyme BBY suffit au classement de ce dossier grossier et au déclenchement d’une procédure de destitution contre lui, comme ce fut le cas pour le président Nixon avec l’affaire « Watergate », écrit Ousmane Sonko.\r\n\r\nMacky Sall, pense-t-il, ne peut convaincre aucun sénégalais qu’il n’est pas derrière cette affaire. « Que peut-il dire lorsque son procureur a interrompu l’enquête dès lors que celle-ci s’acheminait vers la piste et la convocation probable dudit responsable de BBY, d’un médecin et d’un avocat cités dans l’affaire ? Que peut-il dire lorsque l’Etat, dans une affaire supposée privée, kidnappe et isole la victime présumée, à l’insu même de son père et de sa famille qui sont sans nouvelle d’elle depuis le déclenchement de cette mascarade. Monsieur le président, vous ne pouvez convaincre aucun Sénégalais. Tous savent que votre seule compétence, c’est le complot politique contre vos adversaires », conclut Ousmane Sonko qui donne rendez-vous aux Sénégalais « dans les prochaines heures pour une importante déclaration ».', 'pol', 'mrdiop', '2021-02-25'),
(12, '../images/pol.jpg', 'Mbao : Le maire Ablaye Pouye infecté par la Covid-19', 'Malgré les efforts dans la sensibilisation, la pandémie de Covid-19 est en train de faire des ravages dans le District sanitaire de Mbao qui polarise les communes de Thiaroye, Mbao, Thiaroye/Mer, Diamaguene-Sicap Mbao, Thiaroye Gare et Tivaouane Diacksao.\r\n\r\nD’ailleurs, rapporte L’AS qui vend la mèche, le maire de Mbao, Ablaye Pouye, est infecté par le virus de la Covid-19. Depuis son lit d’hôpital, M. Pouye a envoyé un message à ses administrés pour leur demander de faire attention à cette maladie très virale. ', 'pol', 'mrdiop', '2021-02-25'),
(13, '../images/fd.jpg', 'Ivre comme un Polonais, il débarque aux funérailles de son père et…', 'Oumar Diouf, 31 ans, a mené la vie dure à son père jusqu’à ce que ce dernier rende l’âme.\r\n\r\nIvre mort, il se rend aux funérailles de son défunt papa et menace de mort un soutien de la famille avec un couteau.\r\n\r\nSelon L\'Observateur qui donne la nouvelle, les faits ont eu lieu, la semaine dernière, au quartier Darou Rahmane de Rufisque.\r\n\r\nInformée, la police débarque sur les lieux pour le neutraliser.\r\n\r\nArrêté, il a été déféré au parquet, hier, pour violence à ascendant et menaces de mort.\r\n\r\nLe mis en cause est connu des fichiers de la police pour avoir été emprisonné à deux reprises pour usage de chanvre indien. ', 'fd', 'mrdiop', '2021-02-25'),
(14, '../images/fd.jpg', 'Grossesse hors mariage : Une célibataire jette son nouveau-né au marché Ndoumbé Diop de Diourbel', 'Un nouveau-né enveloppé dans un drap a été retrouvé au marché Ndoumbé Diop de Diourbel. L\'auteur des faits, une célibataire âgée 27 ans, a contracté une grossesse et a accouché samedi dernier avant de jeter discrètement son nouveau-né d\'après nos sources de Seneweb proches de l\'enquête. Mais la dame a été aperçue par un passant qui avait des suspicions. \r\n\r\nEn tentant de prendre la fuite, la mère de nouveau-né de sexe masculin a été interpellée par des individus.\r\n\r\nAlertés, les policiers du commissariat central de Diourbel sont arrivés très rapidement sur les lieux indiqués. Après le constat des faits, les éléments du commissaire Mor Ngom se sont rendus aussi au domicile de la mise en cause. Ils y ont découvert du sang au niveau de l\'endroit où la dame a couché au terme de sa grossesse hors mariage.\r\n\r\nPlus de peur que de mal, le nouveau-né se porte très bien selon des sources de Seneweb. Entendue par les enquêteurs, la célibataire a révélé qu\'il ne connaissait pas le père de son nouveau-né.\r\n\r\nÂgée de 27 ans, elle était internée dans une structure sanitaire et se tordait de douleur après son accouchement. Toutefois, elle pourrait même être déférée ce mardi au parquet de Diourbel pour abandon d\'un nouveau-né.\r\n\r\n', 'fd', 'mrdiop', '2021-02-25'),
(15, '../images/sp.jpg', 'Gaston Mbengue va démarrer sa saison de lutte, le 4 avril', 'Le promoteur de lutte Gaston Mbengue a prévu d’entamer, le 4 avril, l’organisation de ses combats pour la nouvelle saison, si l’instance de régulation de ce sport le lui autorise.\r\n\r\n\"Partout à travers le monde, les stades sont vides (...) Les gens suivent les compétitions à la télévision. J’ai décidé de faire la même chose en débutant ma saison le 4 avril, si le CNG (Comité national de gestion de la lutte) accepte cette date\", a-t-il dit à la chaîne privée 2STV.\r\n\r\n\"Le CNG estime qu’on peut démarrer la saison en respectant les gestes barrières, avec des combats à huis clos\", a-t-il expliqué, parlant des combats entre Balla Gaye 2 et Bombardier, Eumeu Sène et Lac de Guiers 2, Diène Kaïré et Modou Anta.\r\n\r\nGaston Mbengue dit attendre du Comité national de gestion de la lutte, d’ici à mercredi, la confirmation de la date du 4 avril pour le démarrage des combats qu’il va organiser au cours de la saison.\r\n\r\nIl a prévu de tenir à huis clos, à cette date, le combat Eumeu Sène-Lac de Guiers 2.\r\n\r\nLe porte-parole du CNG, Adama Bopp, a annoncé durant le week-end que les promoteurs de lutte sont autorisés à organiser des combats à partir du 1er mars, mais à huis clos en raison de la pandémie de Covid-19.\r\n\r\nLes activités sportives étaient suspendues au Sénégal depuis mars 2020, à cause de cette pandémie. Mais plusieurs fédérations sportives ont repris les compétitions depuis décembre.', 'sp', 'mrdiop', '2021-02-25'),
(16, '../images/sp.jpg', 'Mbaye Leye hausse le ton contre ses joueurs pour la première fois: “On peut parler de stupidité”', 'Après le 12 sur 12 des débuts de Mbaye Leye, le Standard est actuellement sur un bien moins glorieux 3 sur 15. La défaite à Zulte Waregem a montré que les Rouches avaient encore beaucoup à apprendre pour gagner en régularité. Pour la première fois, l’entraîneur liégeois, qui n’a pas apprécié les erreurs défensives de ses joueurs, a haussé le ton.\r\n\r\nRenversé en trois minutes par Zulte Waregem dimanche, le club liégeois a manqué l’occasion de faire le gros coup du week-end en dépassant Anderlecht au classement. À la place, cette défaite contraint les Rouches à occuper le sixième rang avec un match en plus par rapport à Charleroi et OHL. Sur ses huit derniers matchs toutes compétitions confondues, le Standard a systématiquement encaissé. Mbaye Leye était passablement agacé après la rencontre: “On encaisse trop de buts sur des transitions. Quand on marque deux buts, on ne peut pas perdre ce match.”\r\n\r\n“On encaisse comme des enfants”', 'sp', 'mrdiop', '2021-02-25');

-- --------------------------------------------------------

--
-- Structure de la table `categorie`
--

CREATE TABLE `categorie` (
  `code_categorie` varchar(5) NOT NULL,
  `design_categorie` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `categorie`
--

INSERT INTO `categorie` (`code_categorie`, `design_categorie`) VALUES
('fd', 'FAITS DIVERS'),
('pol', 'POLITIQUE'),
('rel', 'RELIGION'),
('sp', 'SPORT');

-- --------------------------------------------------------

--
-- Structure de la table `member`
--

CREATE TABLE `member` (
  `username` varchar(15) NOT NULL,
  `prenom_membre` varchar(50) NOT NULL,
  `nom_membre` varchar(20) NOT NULL,
  `pwd` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `member`
--

INSERT INTO `member` (`username`, `prenom_membre`, `nom_membre`, `pwd`) VALUES
('issounet', 'Issa Seck', 'Kane', 'dit2020'),
('mrdiop', 'Mouhamed', 'Diop', 'passer');

-- --------------------------------------------------------

--
-- Structure de la table `message`
--

CREATE TABLE `message` (
  `id_message` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `message`
--

INSERT INTO `message` (`id_message`, `name`, `email`, `message`) VALUES
(1, 'malawserras', 'malawserrass@gmail.com', 'Il faut beaucoup plus insister sur le design !');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `article`
--
ALTER TABLE `article`
  ADD PRIMARY KEY (`numero_article`);

--
-- Index pour la table `categorie`
--
ALTER TABLE `categorie`
  ADD PRIMARY KEY (`code_categorie`);

--
-- Index pour la table `member`
--
ALTER TABLE `member`
  ADD PRIMARY KEY (`username`);

--
-- Index pour la table `message`
--
ALTER TABLE `message`
  ADD PRIMARY KEY (`id_message`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `article`
--
ALTER TABLE `article`
  MODIFY `numero_article` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT pour la table `message`
--
ALTER TABLE `message`
  MODIFY `id_message` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
