<html>
<head>
    <title>A PROPOS</title>
    <meta charset="UTF-8" content="width-device-width,initial-scale=1.0">
    <link type="text/css" href="../styles/save.css" rel = "stylesheet">
</head>
  <body>
    <nav>
      
      <ul>
        <li><a href="index.php"> Accueil</a></li>
        <li class="deroulant"><a href="#">Actualites &ensp;</a>
          <ul class="sous">
            <li><a href="categorieart.php?cat=pol">Politique</a></li>
            <li><a href="categorieart.php?cat=fd">Faits Divers</a></li>
            <li><a href="categorieart.php?cat=sp">Sport</a></li>
            <li><a href="categorieart.php?cat=rel">Religion</a></li>
          </ul>
        </li>
        <li><a href="apropos.php">A propos</a></li>
        <li><a href="contact.php">Contact</a></li>
      </ul>

    </nav>
        <center>
                <h3>Qui sommes nous ?</h3></br>
                <h4>Un marche de professionnel ouvert aux amateurs </h4>
                <h3>Notre Savoir faire</h3></br>
                <p>
                    Conscient que la recherche de grand scoop peut s'averer tres delicate pour les amateurs que ce soit sur internet chez des cavistes ou en grandes distribution, nous mettons l'accent sur les points suivants pour vous satisfaire au mieux :
                </p>
        </center>

        <div class="element_a_propos">
           <div class="un_a_proposg">
              <h4>Annonce a des Prix Tres Competitifs</h4>
              <p>
                Nous gerons votre publicite a moindre cout et nous vous garantissons une meilleure visibilte de vos produits en preparant une population cible pour chaque type de produit. 
              </p>
           </div>

           <div class="un_a_proposd">
              <h4>Une grande communaute de followers</h4>
              <p>
                un tres grand nombre de followers pour vous offrir une visibilite tres paticuliere et ca a rassure tous nos partenaires tels que la Boa , la Cbao et la compagnie de telecommunication Free. 
              </p>
           </div>

           <div class="un_a_proposg">
              <h4>Publication d'informations fiables et verifiees</h4>
              <p>
                Une equipe de reporteurs tres dynamique et engage qui respecte aussi l'ethique et la deontologie. Verifiant leurs informations en se basant sur des sources sures et fiables.
              </p>
           </div>

           <div class="un_a_proposd">
              <h4>Disponibilite de nos ressources en permanence 24h/24</h4>
              <p>
                Des resources disponibles a temps reel pour vous satisfaire et vous obliger a penser a nous pour des informations avant tout autre blog.
              </p>
           </div>

        </div>

    <div class="navbar_bottom">
      <p> Siege : Parcelles Assainies Unite 16 villa 331 - Dakar Senegal</p>
    </div>

  </body>
</html>