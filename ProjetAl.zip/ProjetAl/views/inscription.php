<!DOCTYPE html>
<html>
<head>
  <title>INSCRIPTION</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link type="text/css" href="../styles/animate.css" rel = "stylesheet">
  <link type="text/css" href="../styles/pourform.css" rel = "stylesheet">
</head>

<body style="background-color: whitesmoke ;">

  <?php
        if (isset($_GET['r']) and $_GET['r'] == 0 )  {       
            echo "<div class='alert alert-danger' style='border:2px solid red;margin-top:30px;margin-bottom:30px;width:50%;margin-left:25%;animation: bounceInLeft 1 2s;'><center><img src='../Images/error.png' width='42px' height='42px'>***Inscription non efectue.Changez de username et reessayer </center></div>";        

        }
     ?>
 <center><a href="index.php"><img style="margin-top:30px;" src='../images/retour.png' /></a></center>
 <form action="../controller/ctrlerlogin.php" method="post">

  <div class="container">
    <label for="uname"><b>Username</b></label>
    <input type="text" placeholder="Choisissez un Username" name="username" required>

    <label for="uname"><b>Prenoms</b></label>
    <input type="text" placeholder="Enter Prenoms" name="prenoms" required>

    <label for="uname"><b>Noms</b></label>
    <input type="text" placeholder="Enter last name" name="nom" required>

    <label for="psw"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="pwd" minlength="6" required>

    <button type="submit" name="inscription">S'inscrire</button>
  </div>

  <div class="container" style="background-color:#f1f1f1">
    <button type="reset" class="cancelbtn">Cancel</button>
  </div>
</form> 


</body>
</html>
