<?php session_start() ; ?>

<html>
<head>
    <title>CATEGORIE</title>
    <meta charset="UTF-8" content="width-device-width,initial-scale=1.0">
    <link type="text/css" href="../styles/save.css" rel = "stylesheet">
</head>
  <body>
    <nav>
      
      <ul>
        <li><a href="index.php"> Accueil</a></li>
        <li class="deroulant"><a href="#">Actualites &ensp;</a>
          <ul class="sous">
            <li><a href="categorieart.php?cat=pol">Politique</a></li>
            <li><a href="categorieart.php?cat=fd">Faits Divers</a></li>
            <li><a href="categorieart.php?cat=sp">Sport</a></li>
            <li><a href="categorieart.php?cat=rel">Religion</a></li>
          </ul>
        </li>
        <li><a href="apropos.php">A propos</a></li>
        <li><a href="contact.php">Contact</a></li>
        
      </ul>

    </nav>
        <div class="navbar_left"> 
              <?php
              if (isset($_SESSION['username'])) {
                echo "<a href='addarticle.php'><input type='button' class='buttonCo' value='Ajouter un article'></a>" ;
              }
            ?>

            <img src='../images/news.jpg' />
            <img src='../images/nocovid.jpg' />
            <?php
              if (!isset($_SESSION['username'])) echo "<a href='login.php'><input type='button' class='buttonCo' value='Se connecter'></a>" ;
              else {
                echo "<h5 style='font-size:80%;font-style:italic;text-align:center;'>Welcome ".$_SESSION['username']."</h5>";
                echo "<a href='logout.php'><input type='button' class='buttonCo' value='Se Deconnecter'></a>" ;
              }
            ?>
        </div>

        <div class="article_content"> 
            <?php 
             require_once '../modele/database.php';
             require_once '../modele/databasearticle.php';

             if (isset($_GET['cat'])) {

                          $cat=$_GET['cat'];
                          $list=list_articles_cat($cat);
                          $nombre_total_articles = $list->rowCount();
                          $nombre_article_parpage = 2;
                          $nombremax_avapres = 1; //nblien a afficher 
                          $last_page = ceil($nombre_total_articles/$nombre_article_parpage);
                          $pagination = '' ;

                          if (isset ($_GET['page']) && is_numeric($_GET['page'])) {
                            $page_num = $_GET['page'] ;
                          } else {
                              $page_num = 1 ;
                          }

                          if ($page_num < 1) {
                            $page_num = 1 ;
                          } else if ($page_num > $last_page ) {
                              $page_num = $last_page ; // derniere page
                          }
   
                         $limit = 'LIMIT '.($page_num - 1) * $nombre_article_parpage. ',' .$nombre_article_parpage ;
                         $sql="SELECT numero_article, path_image, title_article, descrip_article, code_categorie , username , DATE_FORMAT(pub_date, '%d/%m/%Y a %Hh : %imn') as date from article where code_categorie= '$cat' ORDER BY numero_article desc $limit" ;
                         

                         if ( $last_page != 1){
                              if ($page_num > 1){
                                  $precedent = $page_num - 1 ;
                                  $pagination .= '<a href="categorieart.php?cat='.$cat.'&page='.$precedent.'">Precedent</a> &nbsp;' ;

                                  for ($i = $page_num - $nombremax_avapres ; $i < $page_num ; $i++ ) {
                                    if ($i > 0 ) {
                                        $pagination .= '<a href="categorieart.php?cat='.$cat.'&page='.$i.'">'.$i.'</a> &nbsp;' ;
                                    }
                                  }
                              }

                              $pagination .= '<span style="background-color:black;color:white;font-size:110%;font-weight:bold;">'.$page_num.'</span> &nbsp;';
                              
                              for ($i = $page_num + 1;  $i <= $last_page ; $i++ ) {    
                                        $pagination .= '<a href="categorieart.php?cat='.$cat.'&page='.$i.'">'.$i.'</a> ' ;
                                        if ($i >= $page_num + $nombremax_avapres) {
                                          break ;
                                        }
                                  }

                              if ($page_num != $last_page ){
                                    $next = $page_num + 1 ;
                                    $pagination .= '<a href="categorieart.php?cat='.$cat.'&page='.$next.'">Suivant</a> ' ;
                                  }   

                          }    

                          echo "<p><strong>($nombre_total_articles)</strong> articles disponible pour la categorie ".$cat." !</br>";
                          echo  "Page <b>$page_num</b> sur <b>$last_page</a>";

                          $listparPage=list_articles_bis($sql);

                          if ($listparPage!= null )
                          while ($data = $listparPage->fetch()) {
                              echo "<div class='un_article'>
                                                <div class='image_article'>
                                                    <a href='viewarticle.php?id=".$data['numero_article']."'><img src='".$data['path_image']."' /></a>
                                                </div>

                                               <div class='infos_article'>
                                                  <a href='viewarticle.php?id=".$data['numero_article']."'><h2>".$data['title_article']."</h2></a>
                                                    <p>
                                                      ".substr($data['descrip_article'],0,100)." ... <a href='viewarticle.php?id=".$data['numero_article']."'>Lire la suite</a>                                                      
                                                    </p> 
                                                    <h5>Publie le ".$data['date']." par <span style='color:red;'>".$data['username']."</span></h5> 

                                               </div>

                                            </div>" ;
                          }
                          echo "<center>".$pagination."</center>" ;
                   }
             ?>


        </div>

      


    </div>  

    <div class="navbar_bottom">
      <p> Siege : Parcelles Assainies Unite 16 villa 331 - Dakar Senegal</p>
    </div>

  </body>
</html>