<?php session_start();
    if (!isset($_SESSION['username']))
      header("Location:login.php") ;  
 ?>

<html>
<head>
    <title>Mes articles</title>
    <meta charset="UTF-8" content="width-device-width,initial-scale=1.0">
    <link type="text/css" href="../styles/save.css" rel = "stylesheet">
    <script type="text/javascript">
            
        function confirmDelete( )
        { 
        var nba = document.getElementById('nbart2').value; 
        var nbp = document.getElementById('nbpage'); 
        var p='';
        if (nbp != null ) p = '?page ='.concat(document.getElementById('nbpage').value);
        var r=confirm("Voulez vs supprimer cet article");
            if (r==true)
            {
                var lien = "../controller/ctrlerarticle.php".concat(p);
                var lien = lien.concat('&nbart=' , nba);
                alert(lien);
                //window.location.replace(lien);           
            }
            else
            {
                // do nothing
            }
            return r ;
        }
      
    </script>
</head>
  <body>
    <nav>
      
      <ul>
        <li><a href="index.php"> Accueil</a></li>
        <li class="deroulant"><a href="#">Actualites &ensp;</a>
          <ul class="sous">
            <li><a href="categorieart.php?cat=pol">Politique</a></li>
            <li><a href="categorieart.php?cat=fd">Faits Divers</a></li>
            <li><a href="categorieart.php?cat=sp">Sport</a></li>
            <li><a href="categorieart.php?cat=rel">Religion</a></li>
          </ul>
        </li>
        <li><a href="apropos.php">A propos</a></li>
        <li><a href="contact.php">Contact</a></li>
        
      </ul>

    </nav>
            <?php
                if (isset($_GET['del']) and $_GET['del'] == 'ok')  {       
                    echo "<div class='alert alert-success' style='border:2px solid green;margin-top:10px;margin-bottom:10px;width:50%;margin-left:25%;animation: bounceInLeft 1 2s;'><center>Article supprime avec succes</center></div>";        

                }

                else if (isset($_GET['del']) and $_GET['del'] == '0' ) {
                  echo "<div class='alert alert-danger' style='border:2px solid red;margin-top:10px;margin-bottom:10px;width:50%;margin-left:25%;animation: bounceInLeft 1 2s;'><center>***Suppression non effetue .</center></div>";    
                }

            ?>
        <div class="navbar_left"> 
            
            <img src='../images/news.jpg' />
            <img src='../images/nocovid.jpg' />
            <?php
              if (!isset($_SESSION['username'])) echo "<a href='login.php'><input type='button' class='buttonCo' value='Se connecter'></a>" ;
              else {
                echo "<h5 style='font-size:80%;font-style:italic;text-align:center;'>Welcome ".$_SESSION['username']."</h5>";
                echo "<a href='logout.php'><input type='button' class='buttonCo' value='Se Deconnecter'></a>" ;
              }

            ?>
        </div>

        <div class="article_content"> 
            <?php 
             require_once '../modele/database.php';
             require_once '../modele/databasearticle.php';

             if (isset($_SESSION['username'])) {

                          $usr=$_SESSION['username'];
                          $list=list_articles_usr($usr);
                          $nombre_total_articles = $list->rowCount();
                          $nombre_article_parpage = 2;
                          $nombremax_avapres = 1; //nblien a afficher 
                          $last_page = ceil($nombre_total_articles/$nombre_article_parpage);
                          $pagination = '' ;

                          if (isset ($_GET['page']) && is_numeric($_GET['page'])) {
                            $page_num = $_GET['page'] ;
                          } else {
                              $page_num = 1 ;
                          }

                          if ($page_num < 1) {
                            $page_num = 1 ;
                          } else if ($page_num > $last_page ) {
                              $page_num = $last_page ; // derniere page
                          }
   
                         $limit = 'LIMIT '.($page_num - 1) * $nombre_article_parpage. ',' .$nombre_article_parpage ;
                         $sql="SELECT numero_article, path_image, title_article, descrip_article, code_categorie , username , DATE_FORMAT(pub_date, '%d/%m/%Y a %Hh : %imn') as date from article where username= '$usr' ORDER BY numero_article desc $limit" ;
                         

                         if ( $last_page != 1){
                              if ($page_num > 1){
                                  $precedent = $page_num - 1 ;
                                  $pagination .= '<a href="myarticles.php?page='.$precedent.'">Precedent</a> &nbsp;' ;

                                  for ($i = $page_num - $nombremax_avapres ; $i < $page_num ; $i++ ) {
                                    if ($i > 0 ) {
                                        $pagination .= '<a href="myarticles.php?page='.$i.'">'.$i.'</a> &nbsp;' ;
                                    }
                                  }
                              }

                              $pagination .= '<span style="background-color:black;color:white;font-size:110%;font-weight:bold;">'.$page_num.'</span> &nbsp;';
                              
                              for ($i = $page_num + 1;  $i <= $last_page ; $i++ ) {    
                                        $pagination .= '<a href="myarticles.php?page='.$i.'">'.$i.'</a> ' ;
                                        if ($i >= $page_num + $nombremax_avapres) {
                                          break ;
                                        }
                                  }

                              if ($page_num != $last_page ){
                                    $next = $page_num + 1 ;
                                    $pagination .= '<a href="myarticles.php?page='.$next.'">Suivant</a> ' ;
                                  }   

                          }    

                          echo "<p><strong>($nombre_total_articles)</strong> articles deja ajoutes par l'utuisateur :  ".$usr." !</br>";
                          echo  "Page <b>$page_num</b> sur <b>$last_page</a>";

                          $listparPage=list_articles_bis($sql);
                          $i=0; //compteur id article
                          if ($listparPage!= null )
                          while ($data = $listparPage->fetch()) {
                              $i++;
                              echo "<div class='un_article'>
                                                <div class='image_article'>
                                                    <a href='viewarticle.php?id=".$data['numero_article']."'><img src='".$data['path_image']."' /></a>
                                                </div>

                                               <div class='infos_article'>
                                                  <a href='viewarticle.php?id=".$data['numero_article']."'><h2>".$data['title_article']."</h2></a>
                                                  <input type='hidden' value='".$data['numero_article']."' id='nbart".$i."' /> ";

                                                  if (isset($_GET['page'])) echo "<input type='hidden' value='".$_GET['page']."' id='nbpage' />";
                                                    
                                                    echo "<p>
                                                      ".substr($data['descrip_article'],0,100)." ... <a href='viewarticle.php?id=".$data['numero_article']."'>Lire la suite</a>                                                      
                                                    </p> 
                                                    <center>
                                                            <a href='editarticle.php?nbart=".$data['numero_article']."'><img src='../images/edit.png'/></a>
                                                            &nbsp; &nbsp; 
                                                            <a href='#'><img src='../images/delete.png' onclick='confirmDelete();'/></a>
                                                    </center>

                                               </div>

                                            </div>" ;
                          }
                          echo "<p id='liencourant'><center>".$pagination."</center></p>" ;
                   }
             ?>


        </div>

      


    </div>  

    <div class="navbar_bottom">
      <p> Siege : Parcelles Assainies Unite 16 villa 331 - Dakar Senegal</p>
    </div>

  </body>
</html>