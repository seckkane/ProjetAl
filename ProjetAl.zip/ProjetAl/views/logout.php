<?php
session_start () ;

if (true){
	session_destroy () ;
	echo "	  <script>location.href='index.php'</script>" ;
}

?>