<html>
<head>
    <title>CONTACT</title>
    <meta charset="UTF-8" content="width-device-width,initial-scale=1.0">
    <link type="text/css" href="../styles/save.css" rel = "stylesheet">
    <link type="text/css" href="../styles/animate.css" rel = "stylesheet">
</head>
  <body>
    <nav>
      
      <ul>
        <li><a href="index.php"> Accueil</a></li>
        <li class="deroulant"><a href="#">Actualites &ensp;</a>
          <ul class="sous">
            <li><a href="categorieart.php?cat=pol">Politique</a></li>
            <li><a href="categorieart.php?cat=fd">Faits Divers</a></li>
            <li><a href="categorieart.php?cat=sp">Sport</a></li>
            <li><a href="categorieart.php?cat=rel">Religion</a></li>
          </ul>
        </li>
        <li><a href="apropos.php">A propos</a></li>
        <li><a href="contact.php">Contact</a></li>
        
      </ul>

    </nav>

    <?php
        if (isset($_GET['r']) and $_GET['r'] == 0 )  {       
            echo "<div class='alert alert-danger' style='border:2px solid red;margin-top:30px;margin-bottom:30px;width:50%;margin-left:25%;background-color:pink;animation: bounceInLeft 1 2s;'><center><img src='../Images/error.png' width='42px' height='42px'>***Message non enregistre</center></div>";        

        }

        else if (isset($_GET['r']) and $_GET['r'] == 1 ) {
          echo "<div class='alert alert-success' style='border:2px solid green;margin-top:30px;margin-bottom:30px;background-color:lightgreen;width:50%;margin-left:25%;animation: bounceInLeft 1 2s;'><center><img src='../Images/save.png' width='42px' height='42px'>***Message enregistre avec succes .</center></div>";    
        }
     ?>


    <h5 style="margin-top: 30px;">DIT2 Informations . Newsletter </h5>
            <h2>Un renseignement?</h2>
            <h2>Un devis?</h2>
            <p>
            Veuillez nous laisser un message pour tout avis suggestion ou renseignement.</br>
            Nous allons vous repondre dans les plus bref delais.</br>
                    <form name="myForm" action="../controller/ctrlermessage.php"  method="post">
                       <table class="form-style">
                          <tr>
                             <td>
                                <label>
                                   Votre nom <span class="required">*</span>
                                </label>
                             </td>
                             <td>
                                <input type="text" name="name" class="long" required="true" />
                                <span class="error"></span>
                             </td>
                          </tr>
                          <tr>
                             <td>
                                <label>
                                   Votre adresse e-mail <span class="required">*</span>
                                </label>
                             </td>
                             <td>
                                <input type="email" name="email" class="long" required="true" />
                                <span class="error"></span>
                             </td>
                          </tr>
                          <tr>
                             <td>
                                <label>
                                   Message <span class="required">*</span>
                                </label>
                             </td>
                             <td>
                                <textarea name="message" class="long field-textarea" required="true"></textarea>
                                <span class="error" id="errormsg"></span>
                             </td>
                          </tr>
                          <tr>
                             <td></td>
                             <td>
                                <input type="submit" value="Envoyer" name="myForm">      
                                <input type="reset" value="Réinitialiser"> 
                             </td>
                          </tr>
                       </table>
                    </form>

    <div class="navbar_bottom">
      <p> Siege : Parcelles Assainies Unite 16 villa 331 - Dakar Senegal</p>
    </div>

  </body>
</html>