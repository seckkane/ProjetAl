<html>
<head>
    <title>ARTICLE</title>
    <meta charset="UTF-8" content="width-device-width,initial-scale=1.0">
    <link type="text/css" href="../styles/save.css" rel = "stylesheet">
</head>
  <body>
    <nav>
      
      <ul>
        <li><a href="index.php"> Accueil</a></li>
        <li class="deroulant"><a href="#">Actualites &ensp;</a>
          <ul class="sous">
            <li><a href="categorieart.php?cat=pol">Politique</a></li>
            <li><a href="categorieart.php?cat=fd">Faits Divers</a></li>
            <li><a href="apropos.php">A propos</a></li>
            <li><a href="contact.php">Contact</a></li>
          </ul>
        </li>
        <li><a href="#">Contact</a></li>
        <li><a href="#">A propos</a></li>
      </ul>

    </nav>
      <a href="index.php"><img style="margin-top: 10%;" src='../images/retour.png' /></a>
      <div class="article_show">
        <div class="image_show">
             <?php

              require_once '../modele/database.php';
              require_once '../modele/databasearticle.php';

              if (isset($_GET['id'])) {
                $id=$_GET['id'];
                $article = getarticleById($id);
                $data = $article->fetch() ;
                echo "<img src='".$data['path_image']."'/>";
              }

              ?>
            
        </div>

        <div class="details_article">
                <?php 
                  if (isset($_GET['id'])) {
                    echo "<h2>".$data['title_article']."</h2>" ;
                    echo "<p>".$data['descrip_article']."</p>" ;
                  }  
                ?>
        </div>
        
      </div>

    <div class="navbar_bottom">
      <p> Siege : Parcelles Assainies Unite 16 villa 331 - Dakar Senegal</p>
    </div>

  </body>
</html>