<!DOCTYPE html>
<html>
<head>
    <title>AJOUTER UN ARTICLE</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link type="text/css" href="../styles/animate.css" rel = "stylesheet">
    <link type="text/css" href="../styles/pourform.css" rel = "stylesheet">
    <script type="text/javascript" language="Javascript" src="../styles/jquery.js" > </script>

     <script type="text/javascript">
                $(function (){
                  $("#AJOUTER").click(function(){
                    valid = true ;
                    text = $("#choixCategorie").val() ;

                      if ( text == "0" ) {
                      $("#choixCategorie").css("border-color","#FF0000");
                      valid = false ;
                     }
                     else {
                      $("#choixCategorie").css("border-color","#E9967A");
                     }

                    return valid ;
                  }) ;
                }) ; 
      </script>
</head>

<body style="background-color: whitesmoke ;">

  <?php
        if (isset($_GET['r']) and $_GET['r'] == 0 )  {       
            echo "<div class='alert alert-danger' style='border:2px solid red;margin-top:30px;margin-bottom:30px;width:50%;margin-left:25%;animation: bounceInLeft 1 2s;'><center><img src='../Images/error.png' width='42px' height='42px'>***Mis a jour non efectue. Contactez votre administrateur </center></div>";        

        }
  ?>
<center><a href="index.php"><img style="margin-top: 20px;" src='../images/retour.png' /></a></center>
  <form action="../controller/ctrlerarticle.php" method="post">
  <div class="container">


    <label for="uname"><b>Categorie de l'article</b></label>
    </br>
                                  <select style="margin-top:10px;" name="choixCategorie" id="choixCategorie" >
                                     <option value="0">Veuiller Choisir une categorie</option>
                                     <option value="fd">FAITS DIVERS</option>
                                     <option value="pol">POLITIQUE</option>
                                     <option value="rel">RELIGION</option>
                                     <option value="sp">SPORT</option>                                                                   
                                  </select>

             <?php

              require_once '../modele/database.php';
              require_once '../modele/databasearticle.php';

              if (isset($_GET['nbart'])) {
                $id=$_GET['nbart'];
                $article = getarticleById($id);
                if ($article != null )
                  $data = $article->fetch() ;
              }

              ?>
   
    </br>
    <input type = "hidden" name="idart" value="<?php echo $_GET['nbart'] ; ?>" />
    <label for="uname"><b>Titre de l'article </b></label>
    <input type="text" name="title_article" value="<?php echo $data['title_article'] ?>" required />

    <label for="uname"><b>Description de l'article</b></label></br>
    <textarea name="descrip_article" required > <?php echo $data['descrip_article'] ?> </textarea> 

    <button type="submit" id="AJOUTER" name="majarticle">Mettre a jour</button>
  </div>

  <div class="container" style="background-color:#f1f1f1">
    <button type="reset" class="cancelbtn">Cancel</button>
  </div>
</form> 


</body>
</html>
