<!DOCTYPE html>
<html>
<head>
    <title>AJOUTER UN ARTICLE</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link type="text/css" href="../styles/animate.css" rel = "stylesheet">
    <link type="text/css" href="../styles/pourform.css" rel = "stylesheet">
    <script type="text/javascript" language="Javascript" src="../styles/jquery.js" > </script>

     <script type="text/javascript">
                $(function (){
                  $("#AJOUTER").click(function(){
                    valid = true ;
                    text = $("#choixCategorie").val() ;

                      if ( text == "0" ) {
                      $("#choixCategorie").css("border-color","#FF0000");
                      valid = false ;
                     }
                     else {
                      $("#choixCategorie").css("border-color","#E9967A");
                     }

                    return valid ;
                  }) ;
                }) ; 
      </script><style>
   /* Bordered form */
form {
  border: 3px solid #f1f1f1;
  margin: 2% 20% ;
}

/* Full-width inputs */
input[type=text], input[type=password] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}

/* Set a style for all buttons */
button {
  background-color: grey;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
}

/* Add a hover effect for buttons */
button:hover {
  opacity: 0.8;
}

/* Extra style for the cancel button (red) */
.cancelbtn {
  width: auto;
  padding: 10px 18px;
  background-color: #f44336;
}

/* Center the avatar image inside this container */
.imgcontainer {
  text-align: center;
  margin: 24px 0 12px 0;
}

/* Avatar image */
img.avatar {
  width: 40%;
  border-radius: 50%;
}

/* Add padding to containers */
.container {
  padding: 16px;
}

textarea {
  width: 100% ;
  height: 400px ;
}

select {
  width: 300px ;
  height: 50px ;
  font-size: 100%;
}

/* The "Forgot password" text */
span.psw {
  float: right;
  padding-top: 16px;
}

label {
  margin: 60px 0 40px 0  ;
}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
  span.psw {
    display: block;
    float: none;
  }
  .cancelbtn {
    width: 100%;
  }
} 
</style>

</head>

<body style="background-color: whitesmoke ;">

  <?php
        if (isset($_GET['r']) and $_GET['r'] == 0 )  {       
            echo "<div class='alert alert-danger' style='border:2px solid red;margin-top:30px;margin-bottom:30px;width:50%;margin-left:25%;animation: bounceInLeft 1 2s;'><center><img src='../Images/error.png' width='42px' height='42px'>***Article non ajoute. Contactez votre administrateur </center></div>";        

        }
     ?>
<center><a href="index.php"><img style="margin-top: 20px;" src='../images/retour.png' /></a></center>

 <form action="../controller/ctrlerarticle.php" method="post">

  <div class="container">


    <label for="uname"><b>Categorie de l'article</b></label>
    </br>
                                  <select style="margin-top:10px;" name="choixCategorie" id="choixCategorie" >
                                     <option value="0">Veuiller Choisir une categorie</option>
                                     <option value="fd">FAITS DIVERS</option>
                                     <option value="pol">POLITIQUE</option>
                                     <option value="rel">RELIGION</option>
                                     <option value="sp">SPORT</option>

                                                                             

                                  </select>
   
    </br>
    <label for="uname"><b>Titre de l'article </b></label>
    <input type="text" name="title_article" required>

    <label for="uname"><b>Description de l'article</b></label></br>
    <textarea name="descrip_article"></textarea> 

    <button type="submit" id="AJOUTER" name="addarticle">Ajouter</button>
  </div>

  <div class="container" style="background-color:#f1f1f1">
    <button type="reset" class="cancelbtn">Cancel</button>
  </div>
</form> 


</body>
</html>
