<?php

function addarticle ( $img_path , $title_art , $descrip_art , $code_categorie, $username) {
	
	//Requete permettant d'ajouter un nouveau article
	$sql="INSERT INTO article  VALUES ( NULL, '$img_path', '$title_art' , '$descrip_art' , '$code_categorie', '$username' , current_timestamp() )" ;
    return executesql($sql);
	mysql_close();
}

function updatearticle ($idart , $img_path , $title_art , $descrip_art , $code_categorie) {
	
	//Requete permettant de mettre a jour un article
	$sql="UPDATE article  set path_image='$img_path' , title_article='$title_art' ,  descrip_article='$descrip_art' , code_categorie = '$code_categorie' where numero_article = $idart  " ;
    return executesql($sql);
	mysql_close();
}

function deletearticle ($idart) {
	
	//Requete permettant de supprimer article
	$sql="delete from article where numero_article = $idart" ;
    return executesql($sql);
	mysql_close();
}


function list_articles ( ) {
	
	//Requete permettant de recuperer l'ensemble des articles
	$sql="SELECT * FROM article" ;
    return executesql($sql);
	mysql_close();
}

function list_articles_cat ($cat) {
	
	//Requete permettant de recuperer l'ensemble des articles d'une categorie
	$sql="SELECT * FROM article where code_categorie = '$cat' " ;
    return executesql($sql);
	mysql_close();
}

function list_articles_usr ($usr) {
	
	//Requete permettant de recuperer l'ensemble des articles d'une categorie
	$sql="SELECT * FROM article where username = '$usr' " ;
    return executesql($sql);
	mysql_close();
}


function list_articles_bis ( $sql) {
	
	//Requete permettant de recuperer l'ensemble des articles precis LIMIT
    return executesql($sql);
	mysql_close();
}


function getarticleById($id) {
	
	//Requete permettant de recuperer un article
	$sql="SELECT * FROM article where numero_article = $id " ;
    return executesql($sql);
	mysql_close();
}


function list_categorie ( ) {
	
	//Requete permettant de recuperer l'ensemble des categorie
	$sql="SELECT * FROM categorie" ;
    return executesql($sql);
	mysql_close();
}

?>