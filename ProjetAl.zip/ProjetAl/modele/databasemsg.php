<?php
function addmessage ($name , $email , $message) {
	
	//Requete permettant d'ajouter un message de contact a la base
	$sql="insert into message values ( null , '$name' , '$email' , '$message')" ;
    return executesql($sql);
	mysql_close();
}

?>