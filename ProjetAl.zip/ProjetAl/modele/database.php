<?php
function getconnection ()
{//Fonctioon de connection a la base a travers DES INFOS
  try {
  	$db = new PDO('mysql:host=localhost;dbname=blog_actualites', 'root', 'ingenieur20');
  } catch (PDOEception $e ){
  	  die('Erreur: '.$e->getMessage());
  }
  return $db ;
}


function executesql ($sql) {//Fonction dexecution des requetes SQL
  $db = getconnection();
  return $db->query($sql);
}


?>

