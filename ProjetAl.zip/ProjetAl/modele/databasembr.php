<?php
function checkmember ($username , $password) {
	
	//Requete permettant de verifier um membre
	$sql="SELECT * FROM member WHERE username = '$username' and pwd = '$password' " ;
    return executesql($sql);
	mysql_close();
}

function addmember ($username , $prenoms , $nom , $password) {
	
	//Requete permettant d'ajouter un nouveau membre
	$sql="INSERT INTO member VALUES ( '$username', '$prenoms' , '$nom' , '$password' ) " ;
    return executesql($sql);
	mysql_close();
}

?>