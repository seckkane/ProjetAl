<?php 

session_start();

require_once '../modele/database.php';
require_once '../modele/databasearticle.php';


function chemin_img ($code_categorie) {
	switch ($code_categorie) {
		case 'fd':
			return '../images/fd.jpg';
			break;
		case 'pol':
			return '../images/pol.jpg';
			break;
		case 'rel':
			return '../images/rel.png';
			break;
		case 'sp':
			return '../images/sp.jpg';
			break;
	}
}

if ( isset($_POST['addarticle']) ) { // Controle de traitement pour l'ajout d'un article

	$traitement=addarticle( chemin_img($_POST['choixCategorie']) , addslashes($_POST['title_article']), addslashes($_POST['descrip_article']) , $_POST['choixCategorie'], $_SESSION['username'] ) ;
		
		if ( $traitement) // Le message a bien ete ajoute
			header("Location:../views/index.php?add=ok") ; 
		
		else 
			header("Location:../views/addarticle.php?r=0") ;
	}

if ( isset($_POST['majarticle']) ) { // Controle de traitement pour l'ajout d'un article

	$traitement=updatearticle( $_POST['idart'] , chemin_img($_POST['choixCategorie']) , addslashes($_POST['title_article']), addslashes($_POST['descrip_article']) , $_POST['choixCategorie']) ;
		
		if ( $traitement) // Le message a bien ete ajoute
			header("Location:../views/index.php?up=ok") ; 
		
		else 
			header("Location:../views/addarticle.php?r=0") ;
	}

if ( isset($_GET['nbart']) ) { // Controle de traitement pour la suppression d'un article

	$traitement=deletearticle( $_GET['nbart'] ) ;
		
		if ( $traitement) // L'article a ete bien supprime'
			header("Location:../views/myarticles.php?del=ok") ; 
		
		else 
			header("Location:../views/myarticles.php?del=0") ;
	}

?>