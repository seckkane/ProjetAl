<?php 

require_once '../modele/database.php';
require_once '../modele/databasemsg.php';


if ( isset($_POST['myForm']) ) { // Controle de traitement pour l'ajout d'un message

	$traitement=addmessage($_POST['name'],$_POST['email'],addslashes($_POST['message']) ) ;
		
		if ( $traitement) // Le message a bien ete ajoute
			header("Location:../views/contact.php?r=1") ; 
		
		else 
			header("Location:../views/contact.php?r=0") ;
	}

?>