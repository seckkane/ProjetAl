<?php 

require_once '../modele/database.php';
require_once '../modele/databasemsg.php';
require_once '../modele/databasembr.php';



if ( isset($_POST['seconnecter']) ) { // Controle de traitement pour une connexion

	$traitement=checkmember($_POST['username'] , $_POST['pwd'] ) ; // Verification de l'existence des infos
	if ($traitement->rowCount() != 0 ){
		session_start () ;
		$_SESSION['username']=$_POST['username'] ;
		header("Location:../views/index.php") ;	
	}

	else 
		header("Location:../views/login.php?r=0") ;
		   
	}

if ( isset($_POST['inscription']) ) { // Controle de traitement pour l'ajout d'un nouveau membre

	$traitement=addmember($_POST['username'],$_POST['prenoms'],$_POST['nom'], $_POST['pwd']) ;
		
		if ( $traitement) {// Membre ajoute avec succes 
			session_start () ;
			$_SESSION['username']=$_POST['username'] ;
			header("Location:../views/index.php") ;	
		}
		
		else 
			header("Location:../views/inscription.php?r=0") ;
	}

?>